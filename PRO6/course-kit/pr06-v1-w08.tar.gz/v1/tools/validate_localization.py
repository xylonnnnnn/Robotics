#!/usr/bin/env python3
"""Проверить localization.json ПР08 без сторонних Python-пакетов."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sys
from pathlib import Path
from typing import Any


def _is_number(value: object) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)


def _matches_type(value: object, expected: str) -> bool:
    return {
        "object": isinstance(value, dict),
        "array": isinstance(value, list),
        "string": isinstance(value, str),
        "number": _is_number(value),
        "integer": isinstance(value, int) and not isinstance(value, bool),
        "boolean": isinstance(value, bool),
        "null": value is None,
    }.get(expected, False)


def validate_schema(value: Any, schema: dict[str, Any], path: str = "$") -> list[str]:
    """Validate the JSON Schema subset used by the public PR08 contract."""

    errors: list[str] = []
    expected = schema.get("type")
    expected_types = expected if isinstance(expected, list) else [expected] if expected else []
    if expected_types and not any(_matches_type(value, item) for item in expected_types):
        return [f"{path}: ожидался тип {' или '.join(expected_types)}"]

    if "const" in schema and value != schema["const"]:
        errors.append(f"{path}: ожидалось постоянное значение {schema['const']!r}")
    if "enum" in schema and value not in schema["enum"]:
        errors.append(f"{path}: значение отсутствует в разрешённом списке")

    if isinstance(value, dict):
        required = schema.get("required", [])
        for key in required:
            if key not in value:
                errors.append(f"{path}: отсутствует обязательное поле {key!r}")
        properties = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for key in value.keys() - properties.keys():
                errors.append(f"{path}: неизвестное поле {key!r}")
        for key, child_schema in properties.items():
            if key in value:
                errors.extend(validate_schema(value[key], child_schema, f"{path}.{key}"))

    if isinstance(value, str):
        if len(value) < schema.get("minLength", 0):
            errors.append(f"{path}: строка короче допустимого минимума")
        pattern = schema.get("pattern")
        if pattern and re.search(pattern, value) is None:
            errors.append(f"{path}: строка не соответствует шаблону {pattern!r}")

    if _is_number(value):
        if "minimum" in schema and value < schema["minimum"]:
            errors.append(f"{path}: значение меньше {schema['minimum']}")
        if "maximum" in schema and value > schema["maximum"]:
            errors.append(f"{path}: значение больше {schema['maximum']}")

    return errors


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_result(
    result_path: Path,
    schema_path: Path,
    map_yaml: Path | None = None,
    map_pgm: Path | None = None,
) -> list[str]:
    try:
        result = json.loads(result_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return [f"не удалось прочитать результат {result_path}: {error}"]
    try:
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        return [f"не удалось прочитать схему {schema_path}: {error}"]

    if not isinstance(schema, dict):
        return ["корень JSON Schema должен быть объектом"]
    errors = validate_schema(result, schema)
    if not isinstance(result, dict):
        return errors

    evaluation = result.get("evaluation")
    if isinstance(evaluation, dict):
        total = evaluation.get("tf_queries_total")
        successful = evaluation.get("tf_queries_successful")
        availability = evaluation.get("tf_availability")
        duration = evaluation.get("duration_s")
        warmup = evaluation.get("warmup_s")
        recording = result.get("recording")
        recording_duration = recording.get("duration_s") if isinstance(recording, dict) else None
        if _is_number(duration) and isinstance(total, int) and not isinstance(total, bool):
            # The published contract requires 10 queries per simulated second.
            minimum_queries = math.floor(duration * 10.0 + 1e-6)
            if total < minimum_queries:
                errors.append("$.evaluation.tf_queries_total: запросов меньше, чем требуется при 10 Гц")
        if all(_is_number(value) for value in (duration, warmup, recording_duration)):
            if warmup + duration > recording_duration + 1e-6:
                errors.append("$.evaluation.duration_s: разгон и окно измерения не помещаются в запись")
        if isinstance(total, int) and isinstance(successful, int):
            if successful > total:
                errors.append("$.evaluation: успешных tf2-запросов больше, чем всех запросов")
            elif total > 0 and _is_number(availability):
                expected = successful / total
                if not math.isclose(float(availability), expected, rel_tol=0.0, abs_tol=1e-6):
                    errors.append(
                        "$.evaluation.tf_availability: значение не равно "
                        "tf_queries_successful / tf_queries_total"
                    )

    if (map_yaml is None) != (map_pgm is None):
        errors.append("пути --map-yaml и --map-pgm должны передаваться вместе")
    elif map_yaml is not None and map_pgm is not None:
        map_hashes = result.get("map_sha256")
        if not isinstance(map_hashes, dict):
            errors.append("$.map_sha256: невозможно сверить файлы карты")
        else:
            for key, path in (("map.yaml", map_yaml), ("map.pgm", map_pgm)):
                if not path.is_file():
                    errors.append(f"файл карты не найден: {path}")
                    continue
                if map_hashes.get(key) != file_sha256(path):
                    errors.append(f"$.map_sha256.{key}: SHA-256 не совпадает с {path}")

    return errors


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("result", type=Path)
    parser.add_argument("--schema", type=Path, required=True)
    parser.add_argument("--map-yaml", type=Path)
    parser.add_argument("--map-pgm", type=Path)
    args = parser.parse_args(argv)

    errors = validate_result(args.result, args.schema, args.map_yaml, args.map_pgm)
    if errors:
        print("PR08 localization.json: на доработку", file=sys.stderr)
        for error in errors:
            print(f"- {error}", file=sys.stderr)
        return 1
    print("PR08 localization.json: схема, метрики и SHA-256 карты корректны")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
